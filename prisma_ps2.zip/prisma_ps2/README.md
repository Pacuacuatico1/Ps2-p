# Prisma Engine – port mínimo a PS2 (v1)

Muestra un modelo girando (Gouraud + luz + z-buffer). Sin texturas, sin pad, sin scripts.

## Pasos
1. Convertir el modelo (PC, Python 3 sin librerías):
   `python3 tools/prisma2pm.py modelo.dff model.pm --max-tris 3000`
   (acepta .dff y .glb; ya incluye `model.pm` generado de `vhfyst3.dff`)
2. Compilar (necesita ps2sdk y gsKit, con `PS2SDK` y `PS2DEV` definidos): `make`
3. Ejecutar `prisma.elf` en PCSX2 o en consola real (ps2client / USB).

## Probar sin PS2 (solo PC)
`gcc -Itools/hosttest main.c model_data.c -lm` (con `model_data.c` hecho a partir de `model.pm`)
usa un gsKit simulado y guarda frames .ppm. Así se verificó la orientación y el culling.

## Qué NO está verificado
No he podido compilar con ps2sdk/gsKit reales ni ejecutarlo en PCSX2: las llamadas a
gsKit/dmaKit están escritas de memoria. Si el compilador marca un error, mándamelo.

## Siguientes pasos
Texturas (TXD→gsKit), mando (libpad), varios modelos, huesos/ragdoll, scripts.
