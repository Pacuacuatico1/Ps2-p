#!/usr/bin/env python3
"""Convierte .dff (RenderWare, GTA SA) o .glb a .pm, el formato simple del port PS2.

Uso:  python3 prisma2pm.py modelo.dff modelo.pm [--max-tris 3000]   (0 = sin reducir)
      python3 prisma2pm.py modelo.glb modelo.pm

Formato .pm (little endian):
  char magic[4]="PM01"; u32 nverts; u32 ntris;
  nverts * { float pos[3]; float nrm[3]; u8 rgba[4]; }   (28 bytes)
  ntris * 3 * u32 indices
El modelo sale centrado y escalado a radio 1, con Y hacia arriba.
Sin texturas (v1): el color sale del material (DFF) o baseColorFactor (GLB).
"""
import sys, struct, json, math

def norm(v):
    l = math.sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2])
    return (v[0]/l, v[1]/l, v[2]/l) if l > 1e-12 else (0.0, 1.0, 0.0)

def tri_normal(a, b, c):
    e1 = [b[i]-a[i] for i in range(3)]; e2 = [c[i]-a[i] for i in range(3)]
    return norm((e1[1]*e2[2]-e1[2]*e2[1], e1[2]*e2[0]-e1[0]*e2[2], e1[0]*e2[1]-e1[1]*e2[0]))

# ---------------- DFF ----------------
def chunks(buf, start, end):
    p = start
    while end - p >= 12:
        t, s, v = struct.unpack_from('<III', buf, p)
        if p + 12 + s > end: return
        yield t, p + 12, s, v
        p += 12 + s

def dff_material(buf, off, size):
    col = (255, 255, 255)
    for t, o, s, v in chunks(buf, off, off + size):
        if t == 0x01 and s >= 16:
            col = tuple(buf[o+4:o+7])
        break
    return col

def dff_geometry(buf, off, size, ver):
    ch = list(chunks(buf, off, off + size))
    if not ch or ch[0][0] != 0x01: return None
    _, so, ss, _ = ch[0]
    flags, ntri, nvert = struct.unpack_from('<III', buf, so)
    if nvert == 0: return None
    p = so + 16
    if ver < 0x34000: p += 12
    uvsets = (flags >> 16) & 0xFF
    if uvsets == 0: uvsets = 2 if flags & 0x80 else (1 if flags & 0x4 else 0)
    if flags & 0x8: p += nvert * 4
    p += uvsets * nvert * 8
    tris = []
    for i in range(ntri):
        v2, v1, m, v3 = struct.unpack_from('<HHHH', buf, p + i*8)
        tris.append((v1, v2, v3, m))
    p += ntri * 8
    hasv, hasn = struct.unpack_from('<II', buf, p + 16)
    p += 24
    pos = [struct.unpack_from('<3f', buf, p + i*12) for i in range(nvert)]
    p += nvert * 12
    nrm = [struct.unpack_from('<3f', buf, p + i*12) for i in range(nvert)] if hasn else None
    mats = []
    for t, o, s, v in ch[1:]:
        if t == 0x08:   # lista de materiales
            sub = list(chunks(buf, o, o + s))
            cnt = struct.unpack_from('<I', buf, sub[0][1])[0]
            refs = struct.unpack_from('<%di' % cnt, buf, sub[0][1] + 4)
            mchunks = [c for c in sub[1:] if c[0] == 0x07]
            mi = 0
            for r in refs:
                if 0 <= r < len(mats): mats.append(mats[r])
                elif mi < len(mchunks):
                    mats.append(dff_material(buf, mchunks[mi][1], mchunks[mi][2])); mi += 1
                else: mats.append((255, 255, 255))
        elif t == 0x03 and ntri == 0:   # BinMesh (tiras)
            for t2, o2, s2, v2 in chunks(buf, o, o + s):
                if t2 == 0x50E:
                    fl, nm = struct.unpack_from('<II', buf, o2)
                    q = o2 + 12
                    for _ in range(nm):
                        cnt, mat = struct.unpack_from('<II', buf, q); q += 8
                        idx = struct.unpack_from('<%dI' % cnt, buf, q); q += cnt * 4
                        if fl & 1:
                            for i in range(2, cnt):
                                a, b, d = idx[i-2], idx[i-1], idx[i]
                                if a == b or b == d or a == d: continue
                                if i & 1: a, b = b, a
                                tris.append((a, b, d, mat))
                        else:
                            for i in range(0, cnt - 2, 3):
                                tris.append((idx[i], idx[i+1], idx[i+2], mat))
    return pos, nrm, tris, mats

def load_dff(path):
    buf = open(path, 'rb').read()
    top = list(chunks(buf, 0, len(buf)))
    if not top or top[0][0] != 0x10: raise SystemExit('No es un DFF valido')
    _, co, cs, _ = top[0]
    frames, geoms, atomics, names = [], [], [], []
    for t, o, s, v in chunks(buf, co, co + cs):
        if t == 0x0E:
            st = next(chunks(buf, o, o + s))
            n = struct.unpack_from('<I', buf, st[1])[0]
            for i in range(n):
                f = struct.unpack_from('<12f i', buf, st[1] + 4 + i*56)
                frames.append((f[0:9], f[9:12], f[12]))
            names = []
            for t2, o2, s2, v2 in list(chunks(buf, o, o + s))[1:]:
                if t2 == 0x03:
                    nm = ''
                    for t3, o3, s3, v3 in chunks(buf, o2, o2 + s2):
                        if t3 == 0x253F2FE: nm = buf[o3:o3+s3].split(b'\0')[0].decode('latin1').lower()
                    names.append(nm)
        elif t == 0x1A:
            sub = list(chunks(buf, o, o + s))
            for t2, o2, s2, v2 in sub[1:]:
                if t2 == 0x0F: geoms.append(dff_geometry(buf, o2, s2, v2))
        elif t == 0x14:
            st = next(chunks(buf, o, o + s))
            fr, ge, fl = struct.unpack_from('<III', buf, st[1])
            atomics.append((fr, ge, fl))
    if not atomics: atomics = [(-1, i, 4) for i in range(len(geoms))]

    def apply(fi, p, trans=True):
        g = 0
        while 0 <= fi < len(frames) and g < 64:
            m, ps, par = frames[fi]
            x = p[0]*m[0] + p[1]*m[3] + p[2]*m[6]
            y = p[0]*m[1] + p[1]*m[4] + p[2]*m[7]
            z = p[0]*m[2] + p[1]*m[5] + p[2]*m[8]
            p = (x + ps[0], y + ps[1], z + ps[2]) if trans else (x, y, z)
            fi = par; g += 1
        return p

    out = []   # lista de (pos, nrm, color) por triangulo
    for fr, ge, fl in atomics:
        if not (fl & 4) or not (0 <= ge < len(geoms)) or geoms[ge] is None: continue
        nm = names[fr] if 0 <= fr < len(names) else ''
        if nm.endswith('_dam') or nm.endswith('_vlo'): continue
        pos, nrm, tris, mats = geoms[ge]
        for a, b, c, m in tris:
            if max(a, b, c) >= len(pos): continue
            col = mats[m] if m < len(mats) else (255, 255, 255)
            P = [apply(fr, pos[i]) for i in (a, b, c)]
            # ejes GTA (Z arriba) -> Y arriba: (x, z, -y)
            P = [(q[0], q[2], -q[1]) for q in P]
            if nrm:
                N = [apply(fr, nrm[i], False) for i in (a, b, c)]
                N = [norm((q[0], q[2], -q[1])) for q in N]
            else:
                N = [tri_normal(*P)] * 3
            out.append((P, N, col))
    return out

# ---------------- GLB ----------------
def mat_mul(a, b):  # column-major 4x4
    return [sum(a[k*4 + r] * b[c*4 + k] for k in range(4)) for c in range(4) for r in range(4)]

def node_matrix(n):
    if 'matrix' in n: return list(n['matrix'])
    t = n.get('translation', [0, 0, 0]); q = n.get('rotation', [0, 0, 0, 1]); s = n.get('scale', [1, 1, 1])
    x, y, z, w = q
    r = [1-2*(y*y+z*z), 2*(x*y+z*w), 2*(x*z-y*w), 0,
         2*(x*y-z*w), 1-2*(x*x+z*z), 2*(y*z+x*w), 0,
         2*(x*z+y*w), 2*(y*z-x*w), 1-2*(x*x+y*y), 0, 0, 0, 0, 1]
    for c in range(3):
        for rr in range(3): r[c*4 + rr] *= s[c]
    r[12], r[13], r[14] = t
    return r

def load_glb(path):
    d = open(path, 'rb').read()
    if d[:4] != b'glTF': raise SystemExit('No es un GLB valido')
    p = 12; js = None; binc = b''
    while p < len(d):
        ln, ty = struct.unpack_from('<II', d, p)
        body = d[p+8:p+8+ln]
        if ty == 0x4E4F534A: js = json.loads(body)
        elif ty == 0x004E4942: binc = body
        p += 8 + ln
    CT = {5120: 'b', 5121: 'B', 5122: 'h', 5123: 'H', 5125: 'I', 5126: 'f'}
    NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}
    def acc(i):
        a = js['accessors'][i]; bv = js['bufferViews'][a['bufferView']]
        n = NC[a['type']]; fmt = CT[a['componentType']]; sz = struct.calcsize(fmt)
        stride = bv.get('byteStride', n * sz); base = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
        return [struct.unpack_from('<%d%s' % (n, fmt), binc, base + k*stride) for k in range(a['count'])]
    out = []
    def walk(ni, parent):
        n = js['nodes'][ni]; m = mat_mul(parent, node_matrix(n))
        if 'mesh' in n:
            for prim in js['meshes'][n['mesh']]['primitives']:
                if prim.get('mode', 4) != 4: continue
                at = prim['attributes']
                pos = [(m[0]*x+m[4]*y+m[8]*z+m[12], m[1]*x+m[5]*y+m[9]*z+m[13], m[2]*x+m[6]*y+m[10]*z+m[14]) for x, y, z in acc(at['POSITION'])]
                nrm = None
                if 'NORMAL' in at:
                    nrm = [norm((m[0]*x+m[4]*y+m[8]*z, m[1]*x+m[5]*y+m[9]*z, m[2]*x+m[6]*y+m[10]*z)) for x, y, z in acc(at['NORMAL'])]
                idx = [i[0] for i in acc(prim['indices'])] if 'indices' in prim else list(range(len(pos)))
                col = (255, 255, 255)
                if 'material' in prim:
                    f = js['materials'][prim['material']].get('pbrMetallicRoughness', {}).get('baseColorFactor')
                    if f: col = tuple(int(max(0, min(1, c)) * 255) for c in f[:3])
                for i in range(0, len(idx) - 2, 3):
                    t = idx[i:i+3]; P = [pos[k] for k in t]
                    N = [nrm[k] for k in t] if nrm else [tri_normal(*P)] * 3
                    out.append((P, N, col))
        for c in n.get('children', []): walk(c, m)
    ident = [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1]
    sc = js['scenes'][js.get('scene', 0)]
    for r in sc['nodes']: walk(r, ident)
    return out


def decimate(tris, target):
    """Reduccion por agrupacion de vertices en rejilla (simple, sin librerias)."""
    pts = [p for P, N, c in tris for p in P]
    lo = [min(p[i] for p in pts) for i in range(3)]; hi = [max(p[i] for p in pts) for i in range(3)]
    span = max(hi[i] - lo[i] for i in range(3)) or 1.0
    def run(cell):
        cl = {}; out = []
        for P, N, c in tris:
            ids = []
            for k in range(3):
                key = tuple(int((P[k][i] - lo[i]) / cell) for i in range(3))
                e = cl.get(key)
                if e is None:
                    e = cl[key] = [len(cl), [0.0]*3, [0.0]*3, 0, c]
                for i in range(3): e[1][i] += P[k][i]; e[2][i] += N[k][i]
                e[3] += 1; ids.append(e)
            if ids[0] is not ids[1] and ids[1] is not ids[2] and ids[0] is not ids[2]:
                out.append(ids)
        res = []
        for ids in out:
            P = [tuple(x / e[3] for x in e[1]) for e in ids]
            N = [norm(e[2]) for e in ids]
            res.append((P, N, ids[0][4]))
        return res
    if len(tris) <= target: return tris
    a, b = span / 400.0, span / 2.0
    best = run(b)
    for _ in range(14):
        m = (a + b) / 2; r = run(m)
        if len(r) > target: a = m
        else: b = m; best = r
    return best

def main():
    args = sys.argv[1:]
    maxt = 3000
    if '--max-tris' in args:
        i = args.index('--max-tris'); maxt = int(args[i+1]); del args[i:i+2]
    if len(args) != 2: raise SystemExit(__doc__)
    src, dst = args
    tris = load_dff(src) if src.lower().endswith('.dff') else load_glb(src)
    if not tris: raise SystemExit('El modelo no tiene triangulos')
    fixed = []
    for P, N, c in tris:   # winding anti-horario segun las normales
        g = tri_normal(*P); a = [N[0][i] + N[1][i] + N[2][i] for i in range(3)]
        if g[0]*a[0] + g[1]*a[1] + g[2]*a[2] < 0: P = [P[0], P[2], P[1]]; N = [N[0], N[2], N[1]]
        fixed.append((P, N, c))
    tris = fixed
    n0 = len(tris)
    if maxt > 0: tris = decimate(tris, maxt)
    if len(tris) != n0: print('Reducido de %d a %d triangulos' % (n0, len(tris)))
    pts = [p for P, N, c in tris for p in P]
    lo = [min(p[i] for p in pts) for i in range(3)]; hi = [max(p[i] for p in pts) for i in range(3)]
    ctr = [(lo[i] + hi[i]) / 2 for i in range(3)]
    rad = max(math.sqrt(sum((p[i]-ctr[i])**2 for i in range(3))) for p in pts) or 1.0
    verts, vmap, idx = [], {}, []
    for P, N, c in tris:
        for k in range(3):
            pp = tuple(round((P[k][i]-ctr[i]) / rad, 5) for i in range(3))
            key = (pp, tuple(round(x, 3) for x in N[k]), c)
            if key not in vmap: vmap[key] = len(verts); verts.append(key)
            idx.append(vmap[key])
    with open(dst, 'wb') as f:
        f.write(b'PM01' + struct.pack('<II', len(verts), len(idx) // 3))
        for pp, nn, c in verts:
            f.write(struct.pack('<6f4B', *pp, *nn, c[0], c[1], c[2], 255))
        f.write(struct.pack('<%dI' % len(idx), *idx))
    print('%s: %d vertices, %d triangulos' % (dst, len(verts), len(idx) // 3))

main()
