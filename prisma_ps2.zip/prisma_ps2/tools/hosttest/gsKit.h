/* gsKit de mentira: dibuja con un rasterizador de CPU y guarda frames .ppm (solo para probar en PC) */
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned long long u64;
typedef struct { int PSM, PSMZ, ZBuffering, DoubleBuffering, Width, Height; } GSGLOBAL;
#define GS_PSM_CT24 0
#define GS_PSMZ_24 0
#define GS_SETTING_ON 1
#define GS_ONESHOT 0
#define GS_ZTEST_ON 1
#define GS_SETREG_RGBAQ(r,g,b,a,q) ((u64)(r) | ((u64)(g)<<8) | ((u64)(b)<<16))
#define D_CTRL_RELE_OFF 0
#define D_CTRL_MFD_OFF 0
#define D_CTRL_STS_UNSPEC 0
#define D_CTRL_STD_OFF 0
#define D_CTRL_RCYC_8 0
#define DMA_CHANNEL_GIF 0
#define SleepThread() exit(1)
static unsigned char *fb; static int *zb; static int W = 640, H = 448, frames_done = 0;
static GSGLOBAL G;
static inline GSGLOBAL *gsKit_init_global(void){ return &G; }
static inline void dmaKit_init(int a,int b,int c,int d,int e,int f){}
static inline void dmaKit_chan_init(int c){}
static inline void gsKit_init_screen(GSGLOBAL *g){ W=g->Width; H=g->Height; fb=calloc(W*H,3); zb=calloc(W*H,sizeof(int)); }
static inline void gsKit_mode_switch(GSGLOBAL *g,int m){}
static inline void gsKit_set_test(GSGLOBAL *g,int t){}
static inline void gsKit_queue_exec(GSGLOBAL *g){}
static inline void gsKit_clear(GSGLOBAL *g,u64 c){ for(int i=0;i<W*H;i++){fb[i*3]=c&255;fb[i*3+1]=(c>>8)&255;fb[i*3+2]=(c>>16)&255;zb[i]=0;} }
static inline void gsKit_sync_flip(GSGLOBAL *g){
  frames_done++;
  if(frames_done==1||frames_done==80||frames_done==160){ char n[64]; sprintf(n,"frame%d.ppm",frames_done); FILE*f=fopen(n,"wb"); fprintf(f,"P6\n%d %d\n255\n",W,H); fwrite(fb,3,W*H,f); fclose(f); }
  if(frames_done>=160) exit(0);
}
static inline void gsKit_prim_triangle_gouraud_3d(GSGLOBAL *g,float x1,float y1,int z1,float x2,float y2,int z2,float x3,float y3,int z3,u64 c1,u64 c2,u64 c3){
  float minx=x1<x2?(x1<x3?x1:x3):(x2<x3?x2:x3), maxx=x1>x2?(x1>x3?x1:x3):(x2>x3?x2:x3);
  float miny=y1<y2?(y1<y3?y1:y3):(y2<y3?y2:y3), maxy=y1>y2?(y1>y3?y1:y3):(y2>y3?y2:y3);
  int x0=(int)minx<0?0:(int)minx, xe=(int)maxx+1>W-1?W-1:(int)maxx+1, y0=(int)miny<0?0:(int)miny, ye=(int)maxy+1>H-1?H-1:(int)maxy+1;
  float d=(y2-y3)*(x1-x3)+(x3-x2)*(y1-y3); if(d==0) return;
  for(int y=y0;y<=ye;y++)for(int x=x0;x<=xe;x++){
    float px=x+0.5f,py=y+0.5f;
    float a=((y2-y3)*(px-x3)+(x3-x2)*(py-y3))/d, b=((y3-y1)*(px-x3)+(x1-x3)*(py-y3))/d, c=1-a-b;
    if(a<0||b<0||c<0) continue;
    int z=(int)(a*z1+b*z2+c*z3); if(z<=zb[y*W+x]) continue; zb[y*W+x]=z;
    for(int k=0;k<3;k++){ float v=a*((c1>>(8*k))&255)+b*((c2>>(8*k))&255)+c*((c3>>(8*k))&255); fb[(y*W+x)*3+k]=(unsigned char)v; }
  }
}
